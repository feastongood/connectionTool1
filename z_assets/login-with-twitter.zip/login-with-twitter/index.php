<html>
<body>
<div align="center">
<h2>Login with Twitter Demo</h2>

Click on the image to start the Demo. <br/>
<a href="login.php"><img src="LoginTwitter.png"/></a>
</div>
</body>

</html>